drop table ecommerce_dashboard
CREATE TABLE ecommerce_dashboard (
    product_id SERIAL PRIMARY KEY,
    producttitle TEXT,
    originalprice NUMERIC(10,2),
    price NUMERIC(10,2),
    sold INTEGER,
    tagtext TEXT,
    dates DATE,
    revenue NUMERIC(12,2),
    discount_percent NUMERIC(5,2),
    category TEXT
);

-- Step 2: Set date format (DD-MM-YYYY)
SET datestyle = 'DMY';

COPY ecommerce_dashboard(producttitle, originalprice, price, sold, tagtext, dates, revenue, discount_percent, category)
FROM 'C:\Users\Public\furniture_data\CLEANED READY FOR SQL.csv'
DELIMITER ','
CSV HEADER;

select * from ecommerce_dashboard;

--1.1 total number of records present in dataset
SELECT COUNT(*) AS total_records FROM ecommerce_dashboard;

-- 1.2 check the column names and their data types
SELECT column_name, data_type
FROM information_schema.columns
WHERE table_name = 'ecommerce_dashboard';

-- 1.3 checking if any column has NULL or missing values
SELECT
    COUNT(*) FILTER (WHERE producttitle IS NULL) AS null_producttitle,
    COUNT(*) FILTER (WHERE originalprice IS NULL) AS null_originalprice,
    COUNT(*) FILTER (WHERE price IS NULL) AS null_price,
    COUNT(*) FILTER (WHERE sold IS NULL) AS null_sold,
    COUNT(*) FILTER (WHERE tagtext IS NULL) AS null_tagtext,
    COUNT(*) FILTER (WHERE dates IS NULL) AS null_dates,
    COUNT(*) FILTER (WHERE revenue IS NULL) AS null_revenue,
    COUNT(*) FILTER (WHERE discount_percent IS NULL) AS null_discount,
    COUNT(*) FILTER (WHERE category IS NULL) AS null_category
FROM ecommerce_dashboard;



-- STEP 2 : DATA CLEANING
-- -----------------------

-- 2.1 removing extra spaces in tagtext column
UPDATE ecommerce_dashboard
SET tagtext = TRIM(tagtext);

-- 2.2 converting all text in tagtext column into lowercase for consistency
UPDATE ecommerce_dashboard
SET tagtext = LOWER(tagtext);

-- 2.3 handling null discount_percent values by recalculating from prices
UPDATE ecommerce_dashboard
SET discount_percent = ROUND(((originalprice - price) / originalprice) * 100, 2)
WHERE discount_percent IS NULL
  AND originalprice IS NOT NULL
  AND originalprice > 0;

-- 2.4 if category column has null values then replacing with 'unknown'
UPDATE ecommerce_dashboard
SET category = 'unknown'
WHERE category IS NULL OR category = '';



-- STEP 3 : BASIC STATISTICAL ANALYSIS
-- -----------------------------------

-- 3.1 finding average, min, max and total for price and sold columns
SELECT
    ROUND(AVG(price), 2) AS avg_price,
    ROUND(MAX(price), 2) AS max_price,
    ROUND(MIN(price), 2) AS min_price,
    ROUND(AVG(sold), 2) AS avg_sold,
    SUM(sold) AS total_sold
FROM ecommerce_dashboard;

-- 3.2 counting how many unique categories and shipping tags are there
SELECT COUNT(DISTINCT category) AS unique_categories,
       COUNT(DISTINCT tagtext) AS unique_tags
FROM ecommerce_dashboard;



-- STEP 4 : SHIPPING TYPE ANALYSIS
-- -------------------------------

-- 4.1 checking how many products belong to each tagtext type
SELECT tagtext, COUNT(*) AS tag_count
FROM ecommerce_dashboard
GROUP BY tagtext
ORDER BY tag_count DESC;

-- 4.2 comparing free shipping vs other types in terms of sales and avg price
SELECT tagtext,
       COUNT(*) AS product_count,
       SUM(sold) AS total_sold,
       ROUND(AVG(price),2) AS avg_price
FROM ecommerce_dashboard
GROUP BY tagtext
ORDER BY total_sold DESC;



-- STEP 5 : CATEGORY LEVEL ANALYSIS
-- --------------------------------

-- 5.1 average price, total sold, total revenue for each category
SELECT category,
       ROUND(AVG(price),2) AS avg_price,
       SUM(sold) AS total_sold,
       ROUND(SUM(revenue),2) AS total_revenue
FROM ecommerce_dashboard
GROUP BY category
ORDER BY total_revenue DESC;

-- 5.2 top 5 best selling categories
SELECT category, SUM(sold) AS total_sold
FROM ecommerce_dashboard
GROUP BY category
ORDER BY total_sold DESC
LIMIT 5;

-- 5.3 least selling categories
SELECT category, SUM(sold) AS total_sold
FROM ecommerce_dashboard
GROUP BY category
ORDER BY total_sold ASC
LIMIT 5;



-- STEP 6 : PRODUCT LEVEL INSIGHTS
-- -------------------------------

-- 6.1 top 10 best selling products
SELECT producttitle, sold, price, category
FROM ecommerce_dashboard
ORDER BY sold DESC
LIMIT 10;

-- 6.2 top 10 products by revenue
SELECT producttitle, category, revenue
FROM ecommerce_dashboard
ORDER BY revenue DESC
LIMIT 10;

-- 6.3 products that have zero sales
SELECT producttitle, price, category
FROM ecommerce_dashboard
WHERE sold = 0;

-- 6.4 products which have highest discount percentage
SELECT producttitle, discount_percent, price, category
FROM ecommerce_dashboard
ORDER BY discount_percent DESC
LIMIT 10;



-- STEP 7 : DATE WISE ANALYSIS
-- ----------------------------

-- 7.1 monthly wise sales and revenue trend
SELECT
    TO_CHAR(dates, 'Month YYYY') AS month_year,
    SUM(sold) AS total_sold,
    ROUND(AVG(price),2) AS avg_price,
    SUM(revenue) AS total_revenue
FROM ecommerce_dashboard
GROUP BY month_year
ORDER BY MIN(dates);

-- 7.2 month which had highest total sales
SELECT
    TO_CHAR(dates, 'Month YYYY') AS month_year,
    SUM(sold) AS total_sold
FROM ecommerce_dashboard
GROUP BY month_year
ORDER BY total_sold DESC
LIMIT 1;



-- STEP 8 : CORRELATION INSIGHTS
-- ------------------------------

-- 8.1 checking relation between price and sold
SELECT
    ROUND(COVAR_POP(price, sold) / (STDDEV_POP(price) * STDDEV_POP(sold)), 3)
    AS correlation_price_sold
FROM ecommerce_dashboard;

-- 8.2 checking relation between discount and sold
SELECT
    ROUND(COVAR_POP(discount_percent, sold) / (STDDEV_POP(discount_percent) * STDDEV_POP(sold)), 3)
    AS correlation_discount_sold
FROM ecommerce_dashboard;



-- STEP 9 : REVENUE AND PROFIT ANALYSIS
-- ------------------------------------

-- 9.1 overall total revenue generated
SELECT ROUND(SUM(revenue),2) AS total_revenue FROM ecommerce_dashboard;

-- 9.2 average revenue for each category
SELECT category, ROUND(AVG(revenue),2) AS avg_revenue
FROM ecommerce_dashboard
GROUP BY category
ORDER BY avg_revenue DESC;

-- 9.3 top 10 categories by total revenue
SELECT category, SUM(revenue) AS total_revenue
FROM ecommerce_dashboard
GROUP BY category
ORDER BY total_revenue DESC
LIMIT 10;

-- 9.4 calculating profit (assuming 20 percent margin)
SELECT category,
       ROUND(SUM(revenue * 0.2),2) AS estimated_profit
FROM ecommerce_dashboard
GROUP BY category
ORDER BY estimated_profit DESC;



-- STEP 10 : ADVANCED INSIGHTS
-- ----------------------------

-- 10.1 finding average discount given in each category
SELECT category,
       ROUND(AVG(discount_percent),2) AS avg_discount
FROM ecommerce_dashboard
GROUP BY category
ORDER BY avg_discount DESC;

-- 10.2 top 5 categories with highest average sold count
SELECT category,
       ROUND(AVG(sold),2) AS avg_sold
FROM ecommerce_dashboard
GROUP BY category
ORDER BY avg_sold DESC
LIMIT 5;

-- 10.3 categorizing products based on price range
SELECT
    CASE
        WHEN price < 50 THEN 'Low (below $50)'
        WHEN price BETWEEN 50 AND 150 THEN 'Medium ($50 - $150)'
        ELSE 'High (above $150)'
    END AS price_range,
    COUNT(*) AS product_count,
    SUM(sold) AS total_sold
FROM ecommerce_dashboard
GROUP BY price_range
ORDER BY total_sold DESC;

-- 10.4 comparing free shipping and paid in terms of avg revenue
SELECT tagtext,
       ROUND(AVG(revenue),2) AS avg_revenue,
       SUM(sold) AS total_sold
FROM ecommerce_dashboard
GROUP BY tagtext
ORDER BY avg_revenue DESC;



-- STEP 11 : FINAL DASHBOARD SUMMARY
-- ----------------------------------

-- 11.1 summary of each category
SELECT category,
       COUNT(*) AS total_products,
       SUM(sold) AS total_sold,
       ROUND(AVG(price),2) AS avg_price,
       ROUND(AVG(discount_percent),2) AS avg_discount,
       ROUND(SUM(revenue),2) AS total_revenue
FROM ecommerce_dashboard
GROUP BY category
ORDER BY total_revenue DESC;

-- 11.2 overall key metrics of dataset
SELECT
    ROUND(AVG(price),2) AS avg_price,
    ROUND(AVG(sold),2) AS avg_sold,
    ROUND(SUM(revenue),2) AS total_revenue,
    ROUND(AVG(discount_percent),2) AS avg_discount
FROM ecommerce_dashboard;
